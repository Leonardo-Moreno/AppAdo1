package com.example.appado1

import android.content.Context
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*
import java.util.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //pra salvar na mémoria
        val sh = getSharedPreferences("Produtos", Context.MODE_PRIVATE)

        //btCalcular se você deseja apenas fazer o cálculo sem Salvar
        btCalcular.setOnClickListener { v: View? ->
            if (!(txtPrecoVenda.text.isNullOrEmpty() && txtPrecoCusto.text.isNullOrEmpty())) {

                var venda = txtPrecoVenda.text.toString()
                var custo = txtPrecoCusto.text.toString()
                var dif = venda!!.toDouble() - custo!!.toDouble()

                if (dif > 0){
                    txtDiferenca.setText("Lucro de:R$"+ String.format("%.2f",dif))
                }else{
                    dif = dif * -1
                    txtDiferenca.setText("Prejuizo de:R$"+String.format("%.2f",dif))
                }
            } else {
                Toast.makeText(this, "Os preços devem ser preenchidos", Toast.LENGTH_SHORT)
                    .show()
            }
        }
        //btnLimpar se vocÊ deseja limpar os campos
        btLimpar.setOnClickListener{v: View? ->
          txtPrecoCusto.text.clear()
            txtPrecoVenda.text.clear()
            txtNomeProduto.text.clear()
            txtDiferenca.text.clear()
        }
        //btnSalvar S você desja Salvar na memoria
        btSalvar.setOnClickListener{v: View? ->
         if (txtNomeProduto.text.isNotEmpty() && txtPrecoCusto.text.isNotEmpty() && txtPrecoVenda.text.isNotEmpty()){

             val str = StringBuilder()
             str.append(txtPrecoCusto.text.toString()).append(";")
             str.append(txtPrecoVenda.text.toString()).append(";")

             sh.edit().putString(txtNomeProduto.text.toString(),str.toString()).apply()
             Toast.makeText(this,"Gravou com Sucesso!!",Toast.LENGTH_SHORT).show()
         }
         else{
             Toast.makeText(this,"Todos os campos devem ser preenchidos",Toast.LENGTH_SHORT).show()
         }

        }
        //btnAbrir se voce deseja abrir um produto salvo na memoria
        btAbrir.setOnClickListener{v: View? ->
            if (txtNomeProduto.text.isNotEmpty()){

                var token = sh.getString(txtNomeProduto.text.toString(),"")

                if (token.isNullOrEmpty()){
                    Toast.makeText(this,"Sem esse Produto"+token.toString(),Toast.LENGTH_SHORT).show()
                }
                else{
                   var tkn = StringTokenizer(token.toString(),";")

                   var custo =tkn.nextToken()
                   var venda = tkn.nextToken()
                   txtPrecoCusto.setText(custo)
                   txtPrecoVenda.setText(venda)
                   var dif = venda!!.toDouble() - custo!!.toDouble()
                   if (dif > 0){
                       txtDiferenca.setText("Lucro de:R$"+ String.format("%.2f",dif))
                   }else{
                       dif = dif * -1
                       txtDiferenca.setText("Prejuizo de:R$"+String.format("%.2f",dif))
                   }

                    Toast.makeText(this,"Carregou",Toast.LENGTH_SHORT).show()
                }
            }
            else{
                Toast.makeText(this,"Nome do produto deve ser preenchido",Toast.LENGTH_SHORT).show()
            }

        }

    }

}